package com.cg.banking.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberexception;

@ControllerAdvice
public class BankingExceptionAspect {
	@ExceptionHandler(AccountNotFoundException.class)
	public ModelAndView handelAccountNotFoundException(Exception e) {
		return new ModelAndView("getAccountDetailsPage","errorMessage",e.getMessage());
	}
	@ExceptionHandler(AccountBlockedException.class)
	public ModelAndView handelAccountBlockedException(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	@ExceptionHandler(BankingServiceDownException.class)
	public ModelAndView handelBankingServiceDownException(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InsufficientAmountException.class)
	public ModelAndView handelInsufficientAmountException(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InvalidAccountTypeException.class)
	public ModelAndView handelInvalidAccountTypeException(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InvalidAmountException.class)
	public ModelAndView handelInvalidAmountException(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InvalidPinNumberexception.class)
	public ModelAndView handelInvalidPinNumberexception(Exception e) {
		return new ModelAndView("#","errorMessage",e.getMessage());
	}
	
}
